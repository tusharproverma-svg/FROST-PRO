package com.tushar.frost;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;

/** स्क्रीन बंद या दूसरे ऐप में होने पर भी सुनता रहता है (सूचना दिखती है, बंद करने के लिए FROST में माइक बटन)। */
public class ListenService extends Service {

    static volatile boolean muted = false;
    static volatile boolean running = false;
    private SpeechRecognizer sr;
    private final Handler h = new Handler(Looper.getMainLooper());
    private static final String CH = "frost_listen";

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        startAsForeground();
        if (!running) {
            running = true;
            h.post(new Runnable() {
                @Override
                public void run() {
                    begin();
                }
            });
        }
        return START_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CH, "FROST सुन रहा है", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(c);
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
        b.setContentTitle("FROST सुन रहा है")
                .setContentText("बंद करने के लिए FROST खोलकर माइक बटन दबाइए")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(pi)
                .setOngoing(true);
        Notification n = b.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(11, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(11, n);
        }
    }

    private void begin() {
        if (!running) {
            return;
        }
        if (muted) {
            h.postDelayed(new Runnable() {
                @Override
                public void run() {
                    begin();
                }
            }, 500);
            return;
        }
        try {
            if (sr == null) {
                sr = SpeechRecognizer.createSpeechRecognizer(this);
                sr.setRecognitionListener(new Listener());
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
            i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            sr.startListening(i);
        } catch (Exception e) {
            retry(1500);
        }
    }

    private void retry(long ms) {
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                begin();
            }
        }, ms);
    }

    private class Listener implements RecognitionListener {
        @Override
        public void onReadyForSpeech(Bundle params) {
        }

        @Override
        public void onBeginningOfSpeech() {
        }

        @Override
        public void onRmsChanged(float rmsdB) {
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
        }

        @Override
        public void onError(int error) {
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                running = false;
                MainActivity.js("try{note('माइक की अनुमति नहीं है। ऐप की अनुमतियों में Microphone चालू कीजिए।')}catch(e){}");
                stopSelf();
                return;
            }
            try {
                sr.cancel();
            } catch (Exception e) {
                // ठीक है
            }
            retry(error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 1500 : 400);
        }

        @Override
        public void onResults(Bundle results) {
            ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (r != null && !r.isEmpty() && r.get(0) != null && r.get(0).trim().length() > 0) {
                String text = r.get(0).trim();
                String q = text.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                MainActivity.js("try{window.__nativeHeard('" + q + "')}catch(e){}");
            }
            retry(250);
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (sr != null) {
                sr.destroy();
            }
        } catch (Exception e) {
            // ठीक है
        }
        sr = null;
        super.onDestroy();
    }
}
